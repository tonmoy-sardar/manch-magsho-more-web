export const environment = {
  production: true,
  // apiEndpoint: "http://132.148.130.125/mach_mangso_more/api/",
  // imageBaseUrl: "http://132.148.130.125/mach_mangso_more/uploads/"
  apiEndpoint: "http://166.62.54.122/mamamo/mach_mangso_more/api/",
  imageBaseUrl: "http://166.62.54.122/mamamo/mach_mangso_more/uploads/"
  

};
