import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-repeatorder',
  templateUrl: './repeatorder.component.html',
  styleUrls: ['./repeatorder.component.scss']
})
export class RepeatorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
